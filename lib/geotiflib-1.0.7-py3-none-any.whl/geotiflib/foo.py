

def foo(x, y):
    return 'foo: %s, %s' % (str(x), str(y))

